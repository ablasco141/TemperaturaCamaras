﻿Imports MySql.Data.MySqlClient


Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load

        'TextBox1.Text = MonthCalendar1.SelectionStart.ToString("yyyy-MM-dd")

        DateTimePicker1.Size = New Size(200, 40)


        ' Configura la conexión a la base de datos
        Dim conexion As New MySqlConnection("server=localhost;user id=root;password=Temporal123.;database=estanco")

        ' Obtén la fecha seleccionada en el MonthCalendar
        Dim fechaSeleccionada2 As String = DateTimePicker1.Value.ToString("yyyy-MM-dd")
        Try
            conexion.Open()

            ' Consulta para verificar si ya existe una fecha en la base de datos
            Dim query As String = "SELECT Temperatura_Camara1,Temperatura_Camara2,Temperatura_Camara3,Temperatura_Camara4,Temperatura_Camara5
                                    FROM temperaturacamaras WHERE Fecha = @fecha"
            Dim comando As New MySqlCommand(query, conexion)
            comando.Parameters.AddWithValue("@fecha", fechaSeleccionada2)

            ' Ejecuta la consulta
            Dim reader As MySqlDataReader = comando.ExecuteReader()

            ' Verifica si se encuentra un registro con la fecha seleccionada
            If reader.HasRows Then
                ' Si se encuentra, recupera los valores y los muestra en los TextBox
                While reader.Read()
                    TextBox1.Text = reader("Temperatura_Camara1").ToString()
                    TextBox2.Text = reader("Temperatura_Camara2").ToString()
                    TextBox3.Text = reader("Temperatura_Camara3").ToString()
                    TextBox4.Text = reader("Temperatura_Camara4").ToString()
                    TextBox5.Text = reader("Temperatura_Camara5").ToString()


                End While
            Else
                ' Si no se encuentra nada, simplemente no hace nada
                MessageBox.Show("No se encontraron datos para la fecha seleccionada.")
                TextBox1.Text = "0"
                TextBox2.Text = "0"
                TextBox3.Text = "0"
                TextBox4.Text = "0"
                TextBox5.Text = "0"
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conexion.Close()
        End Try


    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        ' Configura la conexión a la base de datos
        Dim conexion As New MySqlConnection("server=localhost;user id=root;password=Temporal123.;database=estanco")
        Dim fechaSeleccionada2 As String = DateTimePicker1.Value.ToString("yyyy-MM-dd")

        Try
            conexion.Open()
            Dim query As String = "INSERT INTO temperaturacamaras (Fecha, Temperatura_Camara1, Temperatura_Camara2, Temperatura_Camara3, Temperatura_Camara4, 
                                    Temperatura_Camara5) VALUES (@valor1, @valor2, @valor3, @valor4, @valor5, @valor6)"
            Dim comando As New MySqlCommand(query, conexion)

            ' Agregar parámetros para evitar inyección SQL
            comando.Parameters.AddWithValue("@valor1", fechaSeleccionada2)
            comando.Parameters.AddWithValue("@valor2", TextBox1.Text)
            comando.Parameters.AddWithValue("@valor3", TextBox2.Text)
            comando.Parameters.AddWithValue("@valor4", TextBox3.Text)
            comando.Parameters.AddWithValue("@valor5", TextBox4.Text)
            comando.Parameters.AddWithValue("@valor6", TextBox5.Text)

            ' Ejecutar la consulta
            Dim filasAfectadas As Integer = comando.ExecuteNonQuery()

            If filasAfectadas > 0 Then
                MessageBox.Show("Datos insertados correctamente.")
            Else
                MessageBox.Show("Error al insertar datos.")
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conexion.Close()
        End Try

    End Sub




    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged



        ' Configura la conexión a la base de datos
        Dim conexion As New MySqlConnection("server=localhost;user id=root;password=Temporal123.;database=estanco")

        ' Obtén la fecha seleccionada en el MonthCalendar
        Dim fechaSeleccionada2 As String = DateTimePicker1.Value.ToString("yyyy-MM-dd")
        Try
            conexion.Open()

            ' Consulta para verificar si ya existe una fecha en la base de datos
            Dim query As String = "SELECT Temperatura_Camara1,Temperatura_Camara2,Temperatura_Camara3,Temperatura_Camara4,Temperatura_Camara5
                                    FROM temperaturacamaras WHERE Fecha = @fecha"
            Dim comando As New MySqlCommand(query, conexion)
            comando.Parameters.AddWithValue("@fecha", fechaSeleccionada2)

            ' Ejecuta la consulta
            Dim reader As MySqlDataReader = comando.ExecuteReader()

            ' Verifica si se encuentra un registro con la fecha seleccionada
            If reader.HasRows Then
                ' Si se encuentra, recupera los valores y los muestra en los TextBox
                While reader.Read()
                    TextBox1.Text = reader("Temperatura_Camara1").ToString()
                    TextBox2.Text = reader("Temperatura_Camara2").ToString()
                    TextBox3.Text = reader("Temperatura_Camara3").ToString()
                    TextBox4.Text = reader("Temperatura_Camara4").ToString()
                    TextBox5.Text = reader("Temperatura_Camara5").ToString()


                End While
            Else
                ' Si no se encuentra nada, simplemente no hace nada
                MessageBox.Show("No se encontraron datos para la fecha seleccionada.")
                TextBox1.Text = "0"
                TextBox2.Text = "0"
                TextBox3.Text = "0"
                TextBox4.Text = "0"
                TextBox5.Text = "0"
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conexion.Close()
        End Try

    End Sub


End Class
